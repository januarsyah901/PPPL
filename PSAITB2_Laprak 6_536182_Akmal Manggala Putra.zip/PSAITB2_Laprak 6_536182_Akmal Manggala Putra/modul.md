# Pertemuan VI
## Replikasi Database MySQL di Ubuntu Server

### 6.1 Tujuan Pembelajaran
- Mahasiswa mampu melakukan replikasi database menggunakan MySQL.

### 6.2 Dasar Teori
Replikasi database adalah teknik yang penting dalam manajemen basis data yang memungkinkan kita untuk membuat salinan atau replika data dari sebuah basis data utama ke basis data lainnya secara real-time. Dengan replikasi, kita dapat menghadirkan sistem yang toleran terhadap kegagalan dan meningkatkan ketersediaan data.

Dalam praktikum ini, kita akan menggunakan PuTTY atau alat SSH lainnya untuk melakukan remote Ubuntu Server untuk mengimplementasikan replikasi database MySQL. Kita akan belajar tentang konsep master-slave dalam replikasi, di mana basis data master berperan sebagai sumber utama data, sedangkan basis data slave berperan sebagai salinan data yang terus-menerus diperbarui.

#### 6.2.1 Replikasi Database
Replikasi MySQL adalah proses yang memungkinkan data dari satu server database MySQL (master) untuk disalin secara otomatis ke satu atau lebih server database MySQL (slave).

### 6.3 Alat dan Bahan
#### 6.3.1 Perangkat Keras
- VPS
- Komputer/Laptop

#### 6.3.2 Perangkat Lunak
- PuTTY atau SSH lainnya
- MySQL (1) sebagai Master (di VPS)
- MySQL (2) sebagai Slave (di Komputer/Laptop)

### 6.4 Langkah Percobaan
#### 1. Mengecek versi MySQL di VPS (Master)
Masuk ke Ubuntu Server dan cek versi MySQL.

#### 2. Download MySQL di komputer (Slave)
Download MySQL Community Server sesuai versi (contoh: 8.0.44).

#### 3. Konfigurasi MySQL Slave (my.ini)
Tambahkan file `my.ini` lalu lakukan inisialisasi:

```powershell
.\bin\mysqld --defaults-file=my.ini --initialize-insecure --console
```

Menjalankan MySQL:

```powershell
.\bin\mysqld --console
```

Masuk ke MySQL CLI:

```bash
mysql -u root -P PORT
```

#### 4. Konfigurasi MySQL di Master
Edit file konfigurasi:

```bash
sudo nano /etc/mysql/mysql.conf.d/mysqld.cnf
```

Ubah:

```ini
bind-address = 0.0.0.0
```

Aktifkan:
- `server-id`
- `log_bin`

Restart MySQL:

```bash
sudo service mysql restart
```

#### 5. Membuat User Replikasi
Cek user:

```sql
SELECT user, host FROM mysql.user;
```

Buat user:

```sql
CREATE USER 'replica_user'@'%' IDENTIFIED BY 'abc';
```

Berikan hak akses:

```sql
GRANT REPLICATION SLAVE ON *.* TO 'replica_user'@'%';
```

Reload privilege:

```sql
FLUSH PRIVILEGES;
```

#### 6. Konfigurasi MySQL Slave
Tambahkan di `my.ini`:

```ini
server-id=2
```

Restart MySQL slave.

#### 7. Mengecek Posisi Master
Masuk ke MySQL:

```sql
SHOW MASTER STATUS;
```

Catat:
- `File` (misal: `mysql-bin.000001`)
- `Position` (misal: `1322`)

#### 8. Konfigurasi Slave ke Master
```sql
CHANGE MASTER TO
  MASTER_HOST='IP_VPS',
  MASTER_USER='REPLICA_USER',
  MASTER_PASSWORD='PASSWORD',
  MASTER_LOG_FILE='FILE',
  MASTER_LOG_POS=POS;
```

#### 9. Menjalankan Replikasi
Jalankan:

```sql
START SLAVE;
```

Cek status:

```sql
SHOW SLAVE STATUS\G;
```

Ciri berhasil:
- `Slave_IO_Running: Yes`
- `Slave_SQL_Running: Yes`

#### 10. Pengujian
Buat database di master:

```sql
CREATE DATABASE uji_coba;
```

Cek di slave:

```sql
SHOW DATABASES;
```

Jika muncul → replikasi berhasil.

### 6.5 Tugas & Analisis
- Mengapa database tidak tereplikasi?
- Bagaimana solusi agar database ikut tereplikasi?